<?php

declare(strict_types=1);

// This plugin runs via public.php only - no scheduled execution needed.
